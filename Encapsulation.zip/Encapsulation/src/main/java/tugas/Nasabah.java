/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas;

/**
 *
 * @author Mahasiswa
 */
public class Nasabah {
     private String namaAwal;
     private String namaAkhir;
     private Tabungan tabungan;
     
    public Nasabah(String xnamaAwal, String xnamaAkhir, Tabungan t){
        this.namaAwal = xnamaAwal;
        this.namaAkhir = xnamaAkhir;
        this.tabungan = t;
    }
    
    public void setNamaAwal(String xnamaAwal){
        this.namaAwal = xnamaAwal;
    }
    
    public void setNamaAkhir(String xnamaAkhir){
        this.namaAkhir = xnamaAkhir;
    }
}
