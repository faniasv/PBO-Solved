/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas;

/**
 *
 * @author Mahasiswa
 */
public class Tabungan {
    private int saldo;
    
    public Tabungan(int xsaldo){
        this.saldo = xsaldo;
    }
    
    public int getSaldo(){
        return this.saldo;
    }
    
    public void simpanUang(int jumlah){
        this.saldo += jumlah;
    }
    
    public boolean ambilUang(int jumlah){
        boolean check = false;
        
        if(jumlah>this.saldo){
            check = false;
            System.out.println("Ambil uang gagal.");
        } else if(jumlah<=this.saldo){
            this.saldo -= jumlah;
            System.out.println("Ambil uang berhasil.");
        }return check;
    }
    
    public boolean transfer(int jumlah){
        boolean check = false;
        
        if(jumlah>this.saldo){
            check = false;
            System.out.println("Transfer gagal.");
        } else if(jumlah<=this.saldo){
            this.saldo -= jumlah;
            System.out.println("Transfer berhasil.");
        }return check;
    }
}
