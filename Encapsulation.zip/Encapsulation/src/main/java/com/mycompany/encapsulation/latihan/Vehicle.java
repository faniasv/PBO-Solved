/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.encapsulation.latihan;

/**
 *
 * @author Mahasiswa
 */
public class Vehicle {
    private double load;
    private double maxLoad;
    
    public Vehicle(double mmaxLoad){
        this.maxLoad = mmaxLoad;
    }
    
    public double getLoad(){
        return this.load;
    }
    
    public double getMaxLoad(){
        return this.maxLoad;
    }
    
    public boolean addBox(double weight){
        boolean check = false;
        if(weight+this.load>this.maxLoad){
            check=false;
        }else if(weight+this.load<=this.maxLoad){
            this.load += weight;
            check = true;
        }
        return check;
    }
}
