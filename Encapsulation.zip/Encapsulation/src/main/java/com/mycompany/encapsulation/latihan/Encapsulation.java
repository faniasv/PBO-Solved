/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.encapsulation.latihan;

/**
 *
 * @author Mahasiswa
 */
public class Encapsulation {

    public static void main(String[] args) {
        /*Create a vehicle that can handle 10.000 kilograms weight*/
        System.out.println("Creating a vehicle with a 10.000kg maximum load.");
        Vehicle vehicle = new Vehicle(10000.0);
        
        /*Add a few boxes*/
        System.out.println("Add box #1 (500)" + vehicle.addBox(500));
        System.out.println("Add box #2 (250)" + vehicle.addBox(250));
        System.out.println("Add box #3 (5000)" + vehicle.addBox(5000));
        System.out.println("Add box #4 (4000)" + vehicle.addBox(4000));
        System.out.println("Add box #5 (300)" + vehicle.addBox(300));
        
        /*Print out the final vehicle load*/
        System.out.println("Vehicle load is "+vehicle.getLoad()+ "kg");
        
    }
}
